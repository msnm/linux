#include <iostream>
#include "functions.h"
void print_hello(){
std::cout << "Hello World!";
}
