#!/bin/bash
#Author: msnm
#Createdon: So Mai 20 21:17:33 CEST 2018
#Purpose of maakcron: voert elke minuut een bepaald commando uit
errorRoot="Start the script as root!"
errorArg="One argument needs to be specified. The argument should be a executable file"
if ! [[ $(id -u) -eq 0 ]]; then
  echo $errorRoot
  exit 1;
fi

if ! [[ $# -eq 1 ]]; then
  echo $errorArg
  exit 1;
fi

if [[  -r $1 ]] && [[ -x $1 ]]; then
  "./$1"
fi
